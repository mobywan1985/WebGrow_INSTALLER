# coding=utf-8

from sqlalchemy import DateTime, Boolean, Column, String, Integer, Date

from base import Base


class Sensors(Base):
    __tablename__ = 'sensors'
    id=Column(Integer(), primary_key=True)
    sensor_topic=Column('sensor_topic', String(100))
    sensor_temp_adj=Column('sensor_temp_adj', Integer)
    sensor_humid_adj=Column('sensor_humid_adj', Integer)
    sensor_enabled=Column('sensor_enabled', Boolean)

    def __init__(self, sensor_topic, sensor_temp_adj, sensor_humid_adj, sensor_enabled):
        self.sensor_topic = sensor_topic
        self.sensor_temp_adj = sensor_temp_adj
        self.sensor_humid_adj = sensor_humid_adj
        self.sensor_enabled = sensor_enabled
        