#!/usr/bin/env python
# coding=utf-8

# 1 - imports
import RPi.GPIO as RGPIO
from apscheduler.schedulers.background import BackgroundScheduler
from base import Session
from devices import Devices
from sensors import Sensors
from log import Log
from settings import Settings
from sensorlog import SensorLog
from gpio import GPIO
from schedule import Schedule
from mailer import AlertMailer
import time, datetime, json, os
from sockethelper import SocketHelper
from sqlalchemy import func, desc
import Adafruit_DHT
import logging
import requests
import paho.mqtt.client as mqtt
import random
#time.sleep(10)
DEBUG = True

TRIGGER_NONE = 0
TRIGGER_INTERVAL = 10
TRIGGER_TIMER = 15
TRIGGER_TEMPERATURE = 20
TRIGGER_HUMIDITY = 25
TRIGGER_SCHEDULE = 30


PROTOCOL_GPIO = 0
PROTOCOL_SONOFF = 10
PROTOCOL_TASMOTA = 20



logging.basicConfig(level=logging.DEBUG, filename='/usr/local/bin/webgrow/webgrow.log', filemode='w', format='%(asctime)s - %(levelname)s - %(message)s')
log = logging.getLogger('apscheduler.scheduler')
log.setLevel(logging.WARNING)  # DEBUG

#fmt = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
#h = logging.StreamHandler()
#h.setFormatter(fmt)
#log.addHandler(h)

log = logging.getLogger('apscheduler.executors.default')
log.setLevel(logging.WARNING)  # DEBUG

#fmt = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
#h = logging.StreamHandler()
#h.setFormatter(fmt)
#log.addHandler(h)

#Setup GPIO
RGPIO.setmode(RGPIO.BCM)
RGPIO.setwarnings(False)

#Background scheduler for all jobs#
job_defaults = {
    'coalesce': True,
    'misfire_grace_time': 3
}
device_scheduler = BackgroundScheduler(daemon=True, job_defaults=job_defaults)

session = Session()
devices = session.query(Devices).all()
remote_sensors = session.query(Sensors).filter(Sensors.id > 0)
settings = session.query(Settings).order_by(desc(Settings.id)).limit(1)
sampling_rate = settings[0].sampling
sensor_gpio = settings[0].gpio
sensor_tadj = settings[0].tadj
sensor_hadj = settings[0].hadj
sensor_celsius= settings[0].sensor_celsius
enable_sampling = settings[0].sensor
service_topic = settings[0].topic
use_sensor    = settings[0].display_sensor
device_objects = dict()
sensor_objects = dict() 
mqttc = mqtt.Client("py_controller",transport='websockets')
current_temp = 0
current_humidity = 0
email_alerts = settings[0].alert
alert_mailer = AlertMailer(settings[0].alert_email, settings[0].sender_email, settings[0].sender_password)

dht_sensor_job = None
def read_sensor():
    try:
       global current_temp
       global current_humidity
       global sensor_tadj 
       global sensor_hadj
       if(DEBUG):
          temperature1 = random.randint(10,32)
          temperature2 = random.randint(10,32)
          temperature3 = random.randint(10,32)
          temperature4 = random.randint(10,32)
          humidity1 = random.randint(30,70)
          humidity2 = random.randint(30,70)
          humidity3 = random.randint(30,70)
          humidity4 = random.randint(30,70)
       else:
          humidity1, temperature1 = Adafruit_DHT.read_retry(Adafruit_DHT.AM2302, sensor_gpio)
          time.sleep(15)
          humidity2, temperature2 = Adafruit_DHT.read_retry(Adafruit_DHT.AM2302, sensor_gpio)
          time.sleep(15)
          humidity3, temperature3 = Adafruit_DHT.read_retry(Adafruit_DHT.AM2302, sensor_gpio)
          time.sleep(15)
          humidity4, temperature4 = Adafruit_DHT.read_retry(Adafruit_DHT.AM2302, sensor_gpio)
       
       temps = [round(temperature1,2), round(temperature2,2), round(temperature3,2), round(temperature4,2)]       
       temps.sort()
       humiditys = [round(humidity1,2), round(humidity2,2), round(humidity3,2), round(humidity4,2)]
       humiditys.sort()
       
       if humiditys[2] is not None and temps[2] is not None:
          if(humiditys[2] > 100):
             logging.info('Bogus Read from sensor- Throwing results')
          else:
             if(sensor_celsius):
                current_temp = temps[2]
                current_humidity = humiditys[2]
                logging.info('Success reading sensor! T(C):'+str(temps)+" H:"+str(humiditys)+" - Using T:"+str(round(current_temp,2))+"(C) H:"+str(round(current_humidity,2)))
             else:
                current_temp = (temps[2] * 9/5.0 + 32)
                current_humidity = humiditys[2]
                logging.info('Success reading sensor! T(C):'+str(temps)+" H:"+str(humiditys)+" - Using T:"+str(round(temps[2],2))+"(C):"+str(round(current_temp,2))+"(F) H:"+str(round(current_humidity,2)))
       else:
          logging.info('Failed to get reading from sensor. Try again!')

    except:
       logging.error('Error occured while reading sensor. Continuing')
       
    status = [getDHTTemperature(), getDHTHumidity()]
    log_sensor()
    global use_sensor
    if(use_sensor == 0):
       mqttc.publish("php_return_status",json.dumps(status))

def getDHTTemperature():
    global current_temp
    global sensor_tadj 
    return current_temp+sensor_tadj

def getDHTHumidity():
    global current_humidity
    global sensor_hadj
    return current_humidity+sensor_hadj

def log_sensor():
    if current_temp != 0 and current_humidity != 0:
       log_session = Session()
       now = datetime.datetime.now()
       slog = SensorLog(sensor_id = 0, temperature = current_temp, humidity = current_humidity, log_date = now)
       log_session.add(slog)
       log_session.commit()
       log_session.close()

def getScheduler():
    global device_scheduler
    return device_scheduler
    
class Sensor:
    id = int()
    topic = ''
    tadj = int()
    hadj = int()
    temperature = int()
    humidity = int()
    enabled = False
    def __init__(self, id, topic, tadj, hadj, enabled):
        self.id = id
        self.topic = topic
        self.tadj = tadj
        self.hadj = hadj
        self.enabled = enabled
        self.temperature = 0
        self.humidity = 0
        
    def setValue(self, temp, humid):
        self.temperature = temp
        self.humidity = humid
        logging.info("Received remote sensor reading: "+str(self.topic)+" values(Temperature: "+str(self.temperature)+" Humidity: "+str(self.humidity)+")")
        self.logSensor()
        
    def logValue(self):
        logging.info(self.temperature)
        logging.info(self.humidity)
        
    def getTemperature(self):
        return self.temperature + self.tadj
        
    def getHumidity(self):
        return self.humidity + self.hadj
        
    def logSensor(self):
        if self.temperature != 0 and self.humidity != 0:
           log_session = Session()
           now = datetime.datetime.now()
           slog = SensorLog(sensor_id = self.id, temperature = self.temperature, humidity = self.humidity, log_date = now)
           log_session.add(slog)
           log_session.commit()
           log_session.close()


class Device_Object:
    id = int()
    gpio =  int()
    trigger = int()
    temperature_change = None
    humidity_change = None
    temperature = int()
    humidity = int()
    interval = int()
    duration = int()
    timer = int()
    ip = ''
    protocol = int()
    name = ''
    run = None
    state = None
    last_run_time = None
    mqttObj = None    
    interval_job = None
    temperature_job = None
    humidity_job = None
    timer_job = None
    schedule_jobs = []

    def __init__(self, id, gpio, trigger, t_change, h_change, temp, humid, interval, duration, name, run, state, lastRun, protocol, ip, timer):
        self.id = id
        self.gpio = gpio
        self.trigger = trigger
        self.temperature_change = t_change
        self.humidity_change = h_change
        self.temperature  = temp
        self.humidity = humid
        self.interval = interval
        self.duration = duration
        self.timer = timer
        self.name = name
        self.run = run
        self.state = state
        self.last_run_time = lastRun
        self.interval_job = None
        self.temperature_job = None
        self.humidity_job = None
        self.timer_job = None
        self.schedule_jobs = []
        self.protocol = protocol
        self.ip = ip
        self.load_triggers_from_mysql()
        self.print_name()
        if(self.state == 1 and self.protocol == PROTOCOL_GPIO):
           self.gpio_protocol_on()
        if(self.state == 0 and self.protocol == PROTOCOL_GPIO):
           self.gpio_protocol_off()
        global mqttc
        self.mqttObj = mqttc
        
                
    def print_name(self):
        logging.info('Loading Device: '+self.name)

    def add_schedule_job(self, schedule_id, schedule_state, schedule_runtime, schedule_dow):
        if(self.protocol == PROTOCOL_GPIO):
           job_name = self.gpio
        elif(self.protocol == PROTOCOL_TASMOTA):
           job_name = self.ip
        job = getScheduler().add_job(self.run_schedule, 'cron', args=[schedule_state],hour=int(schedule_runtime.hour), minute=int(schedule_runtime.minute),second=int(schedule_runtime.second),day_of_week=schedule_dow, id='S'+str(schedule_id), name=str(job_name))
        self.schedule_jobs.append(job)
        if self.run == 0:
           job.pause()
        
    
    def add_interval_job(self):
        job = getScheduler().add_job(self.run_device ,'interval', seconds=self.interval, id=str(self.id), name=self.name)
        self.interval_job = job
        if self.run == 0:
           job.pause()
           
    def add_timer_job(self):
        job = getScheduler().add_job(self.run_timer_device ,'interval', seconds=50000, id='TMR'+str(self.id), name=self.name)
        self.timer_job = job;
        if self.run == 0:
           job.pause()
    
    def add_temperature_job(self):
        job = getScheduler().add_job(self.check_temp ,'interval', seconds=sampling_rate, id='T'+str(self.id), name=self.name)
        self.temperature_job = job
        if self.run == 0:
           job.pause()
    
    def add_humidity_job(self):
        job = getScheduler().add_job(self.check_humid ,'interval', seconds=sampling_rate, id='H'+str(self.id), name=self.name)
        self.humidity_job = job
        if self.run == 0:
           job.pause()

    def load_triggers_from_mysql(self):
        try:
          device_session = Session()
          if self.trigger == TRIGGER_INTERVAL:
             self.add_interval_job()
          if self.trigger == TRIGGER_TIMER:
             self.add_timer_job()   
          if self.trigger == TRIGGER_TEMPERATURE:
             self.add_temperature_job()
          if self.trigger == TRIGGER_HUMIDITY:
             self.add_humidity_job()
          if self.trigger == TRIGGER_SCHEDULE:
             schedule = device_session.query(Schedule).filter(Schedule.deviceID == self.id)
             for time in schedule:
                 self.add_schedule_job(time.id, time.onOff, time.runTime, time.day_of_week)
          device_session.close()
        except:
          logging.info('There was an error loading. Continuing anyway.')


    def reload_triggers_from_mysql(self):
        try:
          if (self.interval_job is not None):
              self.interval_job.remove()
              self.interval_job = None
          if (self.temperature_job is not None):
              self.temperature_job.remove()
              self.temerature_job = None
          if (self.humidity_job is not None):
              self.humidity_job.remove()        
              self.humidity_job = None
          if (self.timer_job is not None):
              self.timer_job.remove()
              self.timer_job = None
          logging.info(getScheduler().print_jobs())
          for key, job in enumerate(self.schedule_jobs):
                job.remove()
          self.schedule_jobs = []
          if(self.run == 1):
             self.run = 0
             self.toggle_off()
          self.load_triggers_from_mysql()
        except:
          logging.info('There was an error reloading. Continuing anyway.')

    def run_timer_device(self):
        global device_scheduler
        logging.info("Running timer job: "+self.name)
        self.toggle_on()
        if(self.protocol == PROTOCOL_GPIO):
           logging.info(str(datetime.datetime.now())+': Running Job #'+str(self.id)+' on GPIO '+str(self.gpio)+' for '+str(self.timer)+' seconds')
        elif(self.protocol == PROTOCOL_TASMOTA):
           logging.info(str(datetime.datetime.now())+': Running Job #'+str(self.id)+' on Topic '+str(self.ip)+' for '+str(self.timer)+' seconds')
        device_scheduler.add_job(self.stop_device,'interval', id='del'+str(self.id), seconds=self.timer, coalesce=True)

    def run_device(self):
        global device_scheduler
        self.toggle_on()
        if(self.protocol == PROTOCOL_GPIO):
           logging.info(str(datetime.datetime.now())+': Running Job #'+str(self.id)+' on GPIO '+str(self.gpio)+' for '+str(self.duration)+' seconds')
        elif(self.protocol == PROTOCOL_TASMOTA):
           logging.info(str(datetime.datetime.now())+': Running Job #'+str(self.id)+' on Topic '+str(self.ip)+' for '+str(self.duration)+' seconds')
        device_scheduler.add_job(self.stop_device,'interval', id='del'+str(self.id), seconds=self.duration, coalesce=True)
        
    def stop_device(self):
        global device_scheduler
        if(self.trigger == TRIGGER_TIMER):
           self.stop_device_request()
           tmpsession = Session()
           tmpsession.query(Devices).filter(Devices.id == int(self.id)).update({'run': 0})
           tmpsession.commit()
           tmpsession.close()
        else:
           self.toggle_off()
        if(self.protocol == PROTOCOL_GPIO):
           logging.info(str(datetime.datetime.now())+': Stopping Job #'+str(self.id)+' on GPIO '+str(self.gpio))
        elif(self.protocol == PROTOCOL_TASMOTA):
           logging.info(str(datetime.datetime.now())+': Stopping Job #'+str(self.id)+' on Topic '+str(self.ip))
        device_scheduler.remove_job('del'+str(self.id))
        

           
    def run_schedule(self, state):
        if state == 0:
           self.toggle_off()
        else:
           self.toggle_on()
        if(self.protocol == PROTOCOL_GPIO):
           logging.info(str(datetime.datetime.now())+': Running Job #'+str(self.id)+' on GPIO '+str(self.gpio)+" setting to state "+str(state))
        elif(self.protocol == PROTOCOL_TASMOTA):
           logging.info(str(datetime.datetime.now())+': Running Job #'+str(self.id)+' on Topic '+str(self.ip)+" setting to state "+str(state))

    def run_device_request(self):
         if(self.state == 1):
            self.toggle_off()
         global enable_sampling
         if (self.trigger == TRIGGER_INTERVAL):
             self.interval_job.resume()
         if (self.trigger == TRIGGER_TIMER):
             self.timer_job.modify(next_run_time=datetime.datetime.now())
             
         if (self.trigger == TRIGGER_TEMPERATURE):
             if(enable_sampling == True):
                self.temperature_job.resume()
         if (self.trigger == TRIGGER_HUMIDITY):
             if(enable_sampling == True):
                self.humidity_job.resume()
         if(self.trigger == TRIGGER_SCHEDULE):
             for job in self.schedule_jobs:
                 job.resume()
         self.run = 1
         tmpsession = Session()
         tmpsession.query(Devices).filter(Devices.id == int(self.id)).update({'run': 1})
         tmpsession.commit()
         tmpsession.close()


        
    def stop_device_request(self):
         if(self.state == 1):
            self.toggle_off()
         try:
            if (self.trigger == TRIGGER_INTERVAL):
                self.interval_job.pause()
            if (self.trigger == TRIGGER_TIMER):
                self.timer_job.pause()
            if (self.trigger == TRIGGER_TEMPERATURE):
                self.temperature_job.pause()
            if (self.trigger == TRIGGER_HUMIDITY):
                self.humidity_job.pause()
            if(self.trigger == TRIGGER_SCHEDULE):
                for job in self.schedule_jobs:
                    job.pause()
         except:
            logging.error('Error stopping device.')
         self.run = 0
         tmpsession = Session()
         tmpsession.query(Devices).filter(Devices.id == int(self.id)).update({'run': 0})
         tmpsession.commit()
         tmpsession.close()

    
    def gpio_protocol_off(self):
        logging.info('Device:'+str(self.name)+' - GPIO(OFF):'+str(self.gpio))
        RGPIO.output(int(self.gpio), RGPIO.HIGH)
    def gpio_protocol_on(self):
        logging.info('Device:'+str(self.name)+' - GPIO(ON):'+str(self.gpio))
        RGPIO.output(int(self.gpio), RGPIO.LOW)
    
    def tasmoto_protocol_on(self):
        try:
           logging.info('Device:'+str(self.name)+' - TASMOTA(ON):'+str(self.ip))
           self.mqttObj.publish("cmnd/"+self.ip+"/POWER","1")
        except:
           logging.error('Error in tasmota protocol on.')
    def tasmoto_protocol_off(self):
        try:
           logging.info('Device:'+str(self.name)+' - TASMOTA(OFF):'+str(self.ip))
           self.mqttObj.publish("cmnd/"+self.ip+"/POWER","0")
        except:
           logging.error('Error in tasmota protocol off.')
    def sonoff_protocol_on(self):
        logging.info('SonOff not implemented! Skipping! IP:'+self.ip)
    def sonoff_protocol_off(self):
        logging.info('SonOff not implemented! Skipping! IP:'+self.ip)

    def tasmota_state_off(self):
         if(self.state == 1):
            logging.info('Device:'+str(self.name)+' - TASMOTA(OFF):'+str(self.ip))
            self.state = 0
            tmpsession = Session()
            now = datetime.datetime.now()
            tmpsession.query(Devices).filter(Devices.id == int(self.id)).update({'state': 0})
            if(self.protocol == PROTOCOL_TASMOTA):
               dlog = Log(runTime = now, state = 0, dId = int(self.id), gpio=None, protocol=20, ip=self.ip)
               tmpsession.add(dlog)
            tmpsession.commit()
            tmpsession.close()
            global service_topic
            mqttc.publish("stat/"+service_topic+"/device/"+str(self.id)+"/POWER","OFF", qos=2, retain=True)
    def tasmota_state_on(self):
         if(self.state == 0):
            logging.info('Device:'+str(self.name)+' - TASMOTA(ON):'+str(self.ip))
            self.state = 1
            tmpsession = Session()
            now = datetime.datetime.now()
            tmpsession.query(Devices).filter(Devices.id == int(self.id)).update({"lastRun": now, 'state': 1})
            if(self.protocol == PROTOCOL_TASMOTA):
               dlog = Log(runTime = now, state = 1, dId = int(self.id), gpio=None, protocol=20, ip=self.ip)
               tmpsession.add(dlog)
            tmpsession.commit()
            tmpsession.close()
            global service_topic
            mqttc.publish("stat/"+service_topic+"/device/"+str(self.id)+"/POWER","ON", qos=2, retain=True)

          
    def toggle_off(self):
         if(self.state == 1):
            self.state = 0
            tmpsession = Session()
            now = datetime.datetime.now()
            tmpsession.query(Devices).filter(Devices.id == int(self.id)).update({'state': 0})
            if(self.protocol == PROTOCOL_GPIO):
               self.gpio_protocol_off()
               dlog = Log(runTime = now, state = 0, dId = int(self.id), gpio =int(self.gpio), protocol=0, ip='')
               tmpsession.add(dlog)
            elif(self.protocol == PROTOCOL_SONOFF):
               self.sonoff_protocol_off()
               dlog = Log(runTime = now, state = 0, dId = int(self.id), gpio=None, protocol=10, ip=self.ip)
               tmpsession.add(dlog)
            elif(self.protocol == PROTOCOL_TASMOTA):
               self.tasmoto_protocol_off()
               dlog = Log(runTime = now, state = 0, dId = int(self.id), gpio=None, protocol=20, ip=self.ip)
               tmpsession.add(dlog)
            tmpsession.commit()
            tmpsession.close()
            global service_topic
            mqttc.publish("stat/"+service_topic+"/device/"+str(self.id)+"/POWER","OFF", qos=2, retain=True)

         
    def toggle_on(self):
         if(self.state == 0):
            self.state = 1
            tmpsession = Session()
            now = datetime.datetime.now()
            tmpsession.query(Devices).filter(Devices.id == int(self.id)).update({"lastRun": now, 'state': 1})
            if(self.protocol == PROTOCOL_GPIO):
               self.gpio_protocol_on()
               dlog = Log(runTime = now, state = 1, dId = int(self.id), gpio = int(self.gpio), protocol=0, ip='')
               tmpsession.add(dlog)
            elif(self.protocol == PROTOCOL_SONOFF):
               self.sonoff_protocol_on()
               dlog = Log(runTime = now, state = 1, dId = int(self.id), gpio=None, protocol=10, ip=self.ip)
               tmpsession.add(dlog)
            elif(self.protocol == PROTOCOL_TASMOTA):
               self.tasmoto_protocol_on()
               dlog = Log(runTime = now, state = 1, dId = int(self.id), gpio=None, protocol=20, ip=self.ip)
               tmpsession.add(dlog)
            tmpsession.commit()
            tmpsession.close()
            global service_topic
            mqttc.publish("stat/"+service_topic+"/device/"+str(self.id)+"/POWER","ON", qos=2, retain=True)
            

    def delete_device(self):
        if (self.interval_job is not None):
            self.interval_job.remove()
            self.interval_job = None
        if (self.temperature_job is not None):
            self.temperature_job.remove()
            self.temerature_job = None
        if (self.humidity_job is not None):
            self.humidity_job.remove()
            self.humidity_job = None
        if (self.timer_job is not None):
            self.timer_job.remove()
            self.timer_job = None    
        for key, job in enumerate(self.schedule_jobs):
              job.remove()
        self.schedule_jobs = []
        del self
        
    def disable_sensor_device(self):
        if (self.temperature_job is not None):
            self.temperature_job.pause()
        if (self.humidity_job is not None):
            self.humidity_job.pause()

    def enable_sensor_device(self):
        if(self.run):
            if (self.temperature_job is not None):
                self.temperature_job.reschedule(trigger='interval', seconds=sampling_rate)
                self.temperature_job.resume()
                
            if (self.humidity_job is not None):
                self.humidity_job.reschedule(trigger='interval', seconds=sampling_rate)
                self.humidity_job.resume()


    def check_temp(self):
        global use_sensor
        global current_temp
        if(use_sensor == 0):
           check_temp = getDHTTemperature()
        else:
           for key in sensor_objects.keys():
              if(sensor_objects[key]['object'].id == use_sensor):
                 check_temp = sensor_objects[key]['object'].getTemperature()
        
        try:
              if(self.temperature_change):
                 if(check_temp > self.temperature):
                    if(self.state == 0):
                       logging.info('Temp alert! Temperature is greater than '+str(self.temperature)+'(Current:'+str(check_temp)+') and %s has turned on.' % self.name)
                       if(email_alerts == 1):
                          alert_mailer.send_mail(self.name, 'Time: '+str(datetime.datetime.now())+'\nTemperature Alert! Temperature: '+str(round(current_temp,1))+'F\nTemperature Limit Greater Than: '+str(self.temperature)+'F')
                       self.toggle_on()#toggle_on(temp_jobs[jobid]['gpio'], jobid)
                 else:
                    if(self.state == 1):
                       logging.info('No temp alert, turning off '+self.name)
                       self.toggle_off()#toggle_off(temp_jobs[jobid]['gpio'], jobid)
              else:
                 if(check_temp < self.temperature):
                    if(self.state == 0):
                       logging.info('Temp alert! Temperature is less than '+str(self.temperature)+'(Current:'+str(check_temp)+') and %s has turned on.' % self.name)
                       self.toggle_on()#toggle_on(temp_jobs[jobid]['gpio'], jobid)
                       if(email_alerts == 1):
                          alert_mailer.send_mail(self.name, 'Time: '+str(datetime.datetime.now())+'\nTemperature Alert! Temperature: '+str(round(current_temp,1))+'F\nTemperature Limit Less Than: '+str(self.temperature)+'F')
                 else:
                    if(self.state == 1):
                       logging.info('No temp alert, turning off '+self.name)
                       self.toggle_off()#toggle_off(temp_jobs[jobid]['gpio'], jobid)
        except Exception, e:
               logging.error('Error: '+ str(e))
    
    def check_humid(self):
        global current_humidity
        global use_sensor
        if(use_sensor == 0):
           check_humidity = getDHTHumidity()
        else:
           for key in sensor_objects.keys():
              if(sensor_objects[key]['object'].id == use_sensor):
                 check_humidity = sensor_objects[key]['object'].getHumidity()
        try:
              if(self.humidity_change):
                 if(check_humidity > self.humidity):
                    if(self.state == 0):
                       logging.info('Humidity alert! Humidity is greater than required and %s has turned on.' % self.name)
                       self.toggle_on()#toggle_on(temp_jobs[jobid]['gpio'], jobid)
                       if(email_alerts == 1):
                          alert_mailer.send_mail(self.name, 'Time: '+str(datetime.datetime.now())+'\nHumidity Alert! Humidity: '+str(round(current_humidity,1))+'%\nHumidity Limit Greater Than: '+str(self.humidity)+'%')
                 else:
                    if(self.state == 1):
                       logging.info('No humidity alert, turning off '+self.name)
                       self.toggle_off()#toggle_off(temp_jobs[jobid]['gpio'], jobid)
              else:
                 if(check_humidity < self.humidity):
                    if(self.state == 0):
                       logging.info('Humidity alert! Humidity is less than required and %s has turned on.' % self.name)
                       self.toggle_on()#toggle_on(temp_jobs[jobid]['gpio'], jobid)
                       if(email_alerts == 1):
                          alert_mailer.send_mail(self.name, 'Time: '+str(datetime.datetime.now())+'\nHumidity Alert! Humidity: '+str(round(current_humidity,1))+'%\nHumidity Limit Less Than: '+str(self.humidity)+'%')
                 else:
                    if(device.state == 1):
                       logging.info('No humdity alert, turning off '+self.name)
                       self.toggle_off()#toggle_off(temp_jobs[jobid]['gpio'], jobid)
                            
        except:
            logging.error('Error checking humidity')  
            

def print_scheduler():
    jobs=getScheduler().get_jobs()
    for job in jobs:
       logging.info("APSCHEDULER JOB: "+str(job))

#Load Devices
def make_device(id, gpio, trigger, t_change, h_change, temp, humid, interval, duration, name, run, state, lastRun, protocol, ip, timer):
    device_obj = Device_Object(id, gpio, trigger, t_change, h_change, temp, humid, interval, duration, name, run, state, lastRun, protocol, ip, timer)
    return device_obj
def create_device(d_obj):
    global device_objects
    device_objects.update({d_obj.id : {'object' : d_obj}})
    
for device in devices:
    RGPIO.setup(int(device.gpio), RGPIO.OUT)
    RGPIO.output(int(device.gpio), RGPIO.HIGH)
    device_objects.update({device.id : {'object' : make_device(device.id, device.gpio, device.trigger, device.t_change, device.h_change, device.temp, device.humid, device.interval, device.duration, device.name, device.run, device.state, device.lastRun, device.protocol, device.ip, device.timer)}})
def make_sensor(id, topic, tadj, hadj, enabled):
    sensor_obj = Sensor(id, topic, tadj , hadj, enabled)
    return sensor_obj
    
for fsensor in remote_sensors:
    logging.info("Adding remote sensor: "+fsensor.sensor_topic)
    sensor_objects.update({fsensor.sensor_topic : {'object' : make_sensor(fsensor.id, fsensor.sensor_topic, fsensor.sensor_temp_adj, fsensor.sensor_humid_adj, fsensor.sensor_enabled)}})
    
#Load Sensor
dht_sensor_job = getScheduler().add_job(read_sensor, 'interval', seconds=sampling_rate, id='sensor1', name='Sensor Read')
if(enable_sampling == True):
   dht_sensor_job.resume()
else:
   dht_sensor_job.pause()

device_scheduler.start()
session.close()
#for key in device_objects.keys():
#    device_objects[key]['object'].print_name()
print_scheduler()

  
def reload_settings():
    session = Session()
    settings = session.query(Settings).order_by(desc(Settings.id)).limit(1)
    remote_sensors = session.query(Sensors).filter(Sensors.id > 0)
    global sampling_rate
    global sensor_gpio
    global enable_sampling
    global service_topic
    global sensor_tadj
    global sensor_hadj
    global sensor_celsius
    global use_sensor
    global sensor_objects
    sensor_objects.clear()
    
    for fsensor in remote_sensors:
        logging.info("Adding remote sensor: "+fsensor.sensor_topic)
        sensor_objects.update({fsensor.sensor_topic : {'object' : make_sensor(fsensor.id, fsensor.sensor_topic, fsensor.sensor_temp_adj, fsensor.sensor_humid_adj, fsensor.sensor_enabled)}})
    
    sampling_rate = settings[0].sampling
    sensor_gpio = settings[0].gpio
    enable_sampling = settings[0].sensor
    sensor_celsius = settings[0].sensor_celsius
    mqttc.unsubscribe("cmnd/"+service_topic+"/+/+/+")
    mqttc.unsubscribe("stat/"+service_topic+"/+/+/+")
    service_topic = settings[0].topic
    mqttc.subscribe("cmnd/"+service_topic+"/+/+/+", 0)
    mqttc.subscribe("stat/"+service_topic+"/+/+/+", 0)
    sensor_tadj = settings[0].tadj
    sensor_hadj = settings[0].hadj
    use_sensor = settings[0].display_sensor
    session.close()
    if(enable_sampling == True):
       dht_sensor_job.reschedule(trigger='interval', seconds=sampling_rate)
       dht_sensor_job.resume()
    if(enable_sampling == False):
       dht_sensor_job.pause()
    for key in device_objects.keys():
       if(enable_sampling == False):
          device_objects[key]['object'].disable_sensor_device()
       if(enable_sampling == True):
          device_objects[key]['object'].enable_sensor_device()
    




def on_connect(mqttc, obj, flags, rc):
    logging.info("Connected to MQTT Broker rc: " + str(rc))


def on_message(mqttc, obj, msg):
    #if(DEBUG):
    logging.info("MQTT MSG: "+msg.topic + " " + str(msg.qos) + " " + str(msg.payload))
    global service_topic
    global device_objects
    global sensor_objects
    global use_sensor
    if msg.topic.startswith("stat/") and msg.topic.endswith("POWER"):
       topics = msg.topic.split("/")
       for key in device_objects.keys():
           if(device_objects[key]['object'].ip == topics[1]):
                 if(msg.payload == "ON" and device_objects[key]['object'].state == 0):
                    device_objects[key]['object'].tasmota_state_on()
                 if(msg.payload == "OFF" and device_objects[key]['object'].state == 1):
                    device_objects[key]['object'].tasmota_state_off()                    
                    
    if msg.topic.startswith("tele/") and msg.topic.endswith("SENSOR"):
       topics = msg.topic.split("/")
       if(sensor_objects.get(topics[1]) != 'none'):
          svalues = json.loads(msg.payload)
          sensor_objects[topics[1]]['object'].setValue(svalues['BME280']['Temperature'], svalues['BME280']['Humidity'])
          if(use_sensor == sensor_objects[topics[1]]['object'].id):
             status = [sensor_objects[topics[1]]['object'].getTemperature(), sensor_objects[topics[1]]['object'].getHumidity()]
             mqttc.publish("php_return_status",json.dumps(status))
          
    if msg.topic.startswith("cmnd/"+service_topic+"/"):
       topics = msg.topic.split("/")
       has_gpio = False
       if(topics[2] == 'gpio'):
          for key in device_objects.keys():
              if(device_objects[key]['object'].protocol == PROTOCOL_GPIO and device_objects[key]['object'].gpio == int(topics[3])):
                  has_gpio = True
                  if(topics[4] == "POWER"):
                     if(msg.payload == "ON" or msg.payload == "1"):
                        device_objects[key]['object'].toggle_on()
                     if(msg.payload == "OFF" or msg.payload == "0"):
                        device_objects[key]['object'].toggle_off()
          if(has_gpio == False):
              if(topics[4] == "POWER"):
                 if(msg.payload == "ON" or msg.payload == "1"):
                    print('Turning on gpio :'+str(topics[3]))
                    RGPIO.output(int(topics[3]), RGPIO.LOW)
                 if(msg.payload == "OFF" or msg.payload == "0"):
                    print('Turning off gpio:'+str(topics[3]))
                    RGPIO.output(int(topics[3]), RGPIO.HIGH)
                    
       if(topics[2] == 'device'):
          for key in device_objects.keys():
              if(device_objects[key]['object'].id == int(topics[3])):
                 if(msg.payload == "ON" or msg.payload == "1"):
                    if(topics[4] == "POWER"):
                       device_objects[key]['object'].toggle_on()
                    if(topics[4] == "RUN"):
                       device_objects[key]['object'].run_device_request()
                       print_scheduler()
                 if(msg.payload == "OFF" or msg.payload == "0"):
                    if(topics[4] == "POWER"):
                       device_objects[key]['object'].toggle_off()
                    if(topics[4] == "RUN"):
                       device_objects[key]['object'].stop_device_request()
                       print_scheduler()
    if(msg.topic == 'php_function'):
       d = json.loads(msg.payload)
       #if(DEBUG):
       #logging.info(d['device']+':'+d['function'])
       if(d['function'] == 'apply_schedule'):
           device_objects[int(d['device'])]['object'].reload_triggers_from_mysql()
       if(d['function'] == 'apply'):
          device_objects[int(d['device'])]['object'].toggle_off()
          device_objects[int(d['device'])]['object'].delete_device()
          device_objects[int(d['device'])]['object'] = None     
          session = Session()
          new_device = session.query(Devices).filter(Devices.id == int(d['device']))
          device = new_device[0]
          RGPIO.setup(int(device.gpio), RGPIO.OUT)
          RGPIO.output(int(device.gpio), RGPIO.HIGH)
          device_objects.update({device.id : {'object' : make_device(device.id, device.gpio, device.trigger, device.t_change, device.h_change, device.temp, device.humid, device.interval, device.duration, device.name, device.run, device.state, device.lastRun, device.protocol, device.ip, device.timer)}})
          session.close()
       #if(d['function'] == 'run'):
       #   device_objects[int(d['device'])]['object'].run_device_request()
       #   print_scheduler()
       #if(d['function'] == 'stop'):
       #   device_objects[int(d['device'])]['object'].stop_device_request()
       #   print_scheduler()
       #if(d['function'] == 'off'):
       #   device_objects[int(d['device'])]['object'].toggle_off()
       #if(d['function'] == 'on'):
       #   device_objects[int(d['device'])]['object'].toggle_on()
       if(d['function'] == 'create'):
          session = Session()
          max_devices = session.query(func.max(Devices.id))
          for device in max_devices:
               new_device = session.query(Devices).filter(Devices.id == device[0])
               logging.info("Creating Device: "+new_device[0].name)
               ndevice = new_device[0]
               RGPIO.setup(int(ndevice.gpio), RGPIO.OUT)
               RGPIO.output(int(ndevice.gpio), RGPIO.HIGH)
               device_objects.update({ndevice.id : {'object' : make_device(ndevice.id, ndevice.gpio, ndevice.trigger, ndevice.t_change, ndevice.h_change, ndevice.temp, ndevice.humid, ndevice.interval, ndevice.duration, ndevice.name, ndevice.run, ndevice.state, ndevice.lastRun, ndevice.protocol, ndevice.ip, ndevice.timer)}})
          session.close()
       if(d['function'] == 'delete'):
          device_objects[int(d['device'])]['object'].delete_device()
          device_objects[int(d['device'])]['object'] = None
#       if(d['function'] == 'sql_reload'):
#          sql_reload()
       if(d['function'] == 'get_status'):
          if(use_sensor == 0):
             status = [getDHTTemperature(), getDHTHumidity()]
          else:
             for key in sensor_objects.keys():
                if(sensor_objects[key]['object'].id == use_sensor):
                   status = [sensor_objects[key]['object'].getTemperature(), sensor_objects[key]['object'].getHumidity()]
          mqttc.publish("php_return_status",json.dumps(status))
       if(d['function'] == 'reload_settings'):
          reload_settings()



def on_publish(mqttc, obj, mid):
    logging.info("mid: " + str(mid))


def on_subscribe(mqttc, obj, mid, granted_qos):
    logging.info("Subscribed: " + str(mid) + " " + str(granted_qos))


def on_log(mqttc, obj, level, string):
    logging.info(string)



mqttc.on_message = on_message
mqttc.on_connect = on_connect
#mqttc.on_publish = on_publish
#mqttc.on_subscribe = on_subscribe
# Uncomment to enable debug messages
#mqttc.on_log = on_log
mqttc.connect("localhost", 9001, 60)
mqttc.subscribe("php_function", 0)
mqttc.subscribe("stat/+/POWER", 0)
mqttc.subscribe("cmnd/"+service_topic+"/+/+/+", 0)
mqttc.subscribe("stat/"+service_topic+"/+/+/+", 0)
mqttc.subscribe("tele/+/SENSOR", 0)
logging.info("Master Device Name: "+service_topic)
mqttc.loop_forever()


